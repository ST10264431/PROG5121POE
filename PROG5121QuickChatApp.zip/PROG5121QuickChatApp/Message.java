public class Message {
    private String messageID;
    private String recipient;
    private String message;
    private String messageHash;

    public Message(String messageID, String recipient, String message, String messageHash) {
        this.messageID = messageID;
        this.recipient = recipient;
        this.message = message;
        this.messageHash = messageHash;
    }

    public static boolean checkRecipientCell(String number) {
        return number.startsWith("+") && number.length() <= 13;
    }

    public static String createMessageHash(String messageID, int messageNumber, String messageContent) {
        String[] words = messageContent.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;

        return (messageID.substring(0, 2) + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    public void print() {
        System.out.println("MessageID: " + messageID);
        System.out.println("Message Hash: " + messageHash);
        System.out.println("Recipient: " + recipient);
        System.out.println("Message: " + message);
    }
}
