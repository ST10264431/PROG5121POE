import java.util.*;
import java.io.FileWriter;
import java.io.IOException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class Main {
    static Scanner scanner = new Scanner(System.in);
    static int totalMessagesSent = 0;
    static List<Message> sentMessages = new ArrayList<>();

    public static void main(String[] args) {
        // Login
        if (!login()) {
            System.out.println("Too many failed login attempts. Exiting program.");
            return;
        }

        // Main Menu
        System.out.println("\nWelcome to QuickChat.");
        boolean running = true;

        while (running) {
            System.out.println("\nPlease choose an option:");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Your choice: ");
            String menuChoice = scanner.nextLine().trim();

            switch (menuChoice) {
                case "1":
                    sendMessages();
                    break;
                case "2":
                    System.out.println("Coming Soon.");
                    break;
                case "3":
                    running = false;
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    public static boolean login() {
        String correctUsername = "admin";
        String correctPassword = "1234";
        int attempts = 0;

        while (attempts < 3) {
            System.out.print("Enter username: ");
            String username = scanner.nextLine();
            System.out.print("Enter password: ");
            String password = scanner.nextLine();

            if (username.equals(correctUsername) && password.equals(correctPassword)) {
                System.out.println("Login successful.");
                return true;
            } else {
                System.out.println("Invalid credentials. Try again.");
                attempts++;
            }
        }
        return false;
    }
    
    public static void sendMessages() {
        System.out.print("How many messages do you want to enter? ");
        int numMessages = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < numMessages; i++) {
            System.out.println("\nMessage #" + (i + 1));

            String messageID = generateMessageID();
            System.out.print("Enter recipient cell number: ");
            String recipient = scanner.nextLine();

            if (!Message.checkRecipientCell(recipient)) {
                System.out.println("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
                i--;
                continue;
            }

            System.out.print("Enter your message: ");
            String msg = scanner.nextLine();

            if (msg.length() > 250) {
                System.out.println("Message exceeds 250 characters by " + (msg.length() - 250) + ", please reduce size.");
                i--;
                continue;
            }

            String hash = Message.createMessageHash(messageID, totalMessagesSent + 1, msg);
            Message message = new Message(messageID, recipient, msg, hash);

            System.out.println("\nChoose an option:");
            System.out.println("1. Send Message");
            System.out.println("2. Disregard Message");
            System.out.println("3. Store Message to send later");
            System.out.print("Your choice: ");
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    sentMessages.add(message);
                    totalMessagesSent++;
                    System.out.println("Message successfully sent.");
                    message.print();
                    break;
                case "2":
                    System.out.println("Message discarded.");
                    break;
                case "3":
                    storeMessage(message);
                    System.out.println("Message successfully stored.");
                    break;
                default:
                    System.out.println("Invalid option.");
                    i--;
                    break;
            }
        }

        System.out.println("\nTotal messages sent: " + totalMessagesSent);
    }

    public static String generateMessageID() {
        Random random = new Random();
        int id = 1000000000 + random.nextInt(900000000);
        return String.valueOf(id);
    }

    public static void storeMessage(Message message) {
        try {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            FileWriter writer = new FileWriter("stored_messages.json", true); // append mode
            gson.toJson(message, writer);
            writer.write(System.lineSeparator());
            writer.close();
        } catch (IOException e) {
            System.out.println("Failed to store message: " + e.getMessage());
        }
    }
}
