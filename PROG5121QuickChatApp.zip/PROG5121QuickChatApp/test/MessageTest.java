import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @Test
    public void testCheckRecipientCell_Valid() {
        assertTrue(Message.checkRecipientCell("+27831234567"),
                "Should be valid: starts with '+' and is 13 characters");
    }

    @Test
    public void testCheckRecipientCell_InvalidNoPlus() {
        assertFalse(Message.checkRecipientCell("27831234567"),
                "Should be invalid: missing '+'");
    }

    @Test
    public void testCheckRecipientCell_TooLong() {
        assertFalse(Message.checkRecipientCell("+2783123456789"),
                "Should be invalid: exceeds 13 characters");
    }

    @Test
    public void testCreateMessageHash_CorrectFormat() {
        String hash = Message.createMessageHash("1234567890", 1, "Hi Mike, can you join us for dinner tonight");
        assertEquals("12:1:HITONIGHT", hash);
    }

    @Test
    public void testCreateMessageHash_SingleWord() {
        String hash = Message.createMessageHash("1234567890", 2, "Hello");
        assertEquals("12:2:HELLOHELLO", hash);
    }

    @Test
    public void testMessageLength_UnderLimit() {
        String msg = "Short valid message";
        assertTrue(msg.length() <= 250, "Message should be within 250 characters");
    }

    @Test
    public void testMessageLength_OverLimit() {
        StringBuilder longMsg = new StringBuilder();
        for (int i = 0; i < 260; i++) {
            longMsg.append("a");
        }
        assertTrue(longMsg.length() > 250, "Message should be over 250 characters");
    }
}
